<?php
include("baglan.php");
if(isset($_POST["giris"])){
    
    $keMail=$_POST["eMail"];
    $ksifre=$_POST["sifre"];
    
    if($keMail=="admin" && $ksifre==123456){
        
        session_start();
        echo "<h4>Hoşgeldiniz"."admin"."</h4>"."<br>".
        "<a href='../adminpanel.php'>Admin Panel</a>
        <a href='cikis.php'>Cıkış Yap</a>";
        
    }
    else{

    $sorgu=$db->query("SELECT * FROM ogrenci WHERE eMail='$keMail' and sifre='$ksifre'", PDO::FETCH_ASSOC);

    #kullanici dogrulama
    if($sorgu->rowCount()>0){
        session_start();
        $ad_soyad=$sorgu->fetch();
        $_SESSION["keMail"]=$keMail;
        $_SESSION["ksifre"]=$ksifre;


        #telefon doğrulama - captcha ile
           if ($_POST["guvenlik_kodu"] == $_SESSION["guvenlik_kodu"]) {
            header("refresh:1;url=../blogyaz.php");
          } else {
              echo "güvenlik kodu yanlış";
              header("refresh:2;url=../girisyap.php");
          }

    }
    else{
        echo "E-posta veya şifre yanlış. Ana sayfaya yönlendiriliyorsunuz.";
        header("refresh:2;url=../girisyap.php");
    }
    }
    
}
?>
