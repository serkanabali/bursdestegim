<?php

include '../PHPMailer/src/SMTP.php';
include '../PHPMailer/src/PHPMailer.php';
include '../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\Exception;

if (isset($_POST["gonderMail"])) {
    $TelefonNumarasi = $_POST["tel"];
    $telUzunluk = strlen($TelefonNumarasi);
    $pattern = "/5[0,3,4,5,6][0-9]\d\d\d\d\d\d\d$/";
    $eslesme = preg_match($pattern, $TelefonNumarasi);

    if ($eslesme == 1 && $telUzunluk == 10) {
        


        
        #formdan veriler alındı
        $kadSoyad=$_POST["adSoyad"];
        $keMail=$_POST["eMail"];
        $kkonu=$_POST["konu"];
        $kmesaj=$_POST["mesaj"];
        
        $mail=new PHPMailer();
        $mail->Host="smtp.outlook.com"; #hosting adresi
        $mail->Username="smtpserkandeneme@outlook.com";
        $mail->Password="Deneme.123";
        $mail->Port=587;    #ssl port 465
        $mail->SMTPSecure="tls";
        $mail->isSMTP();
        $mail->SMTPAuth="true";
        $mail->isHTML(true);
        $mail->CharSet="UTF-8";
        $mail->setLanguage('tr','PHPMailer/Language/');
        //$mail->SMTPDebug=2; #kapatılırsa debug görünmez
        $mail->setFrom('smtpserkandeneme@outlook.com',"Gönderici");             //gönderen
        $mail->addAddress('smtpserkandeneme@outlook.com',"Admin");              //alıcı
        $mail->Subject="Mail gönderimi";                                 //mesaj konu başlığı
        
        #formdan içerik değişkeni oluşturuldu
        $icerik="Gönderenin Adı: ".$kadSoyad."<br>".
            "Gönderenin Mail Adresi: ".$keMail."<br>".
            "Konu: ".$kkonu."<br>".
            "Mesaj: ".$kmesaj;
        $mail->MsgHTML($icerik);    #mesajın html olduğu belirtildi
        $mail_gonder=$mail->send(); #html oldugu dogrulandı
        
        $mail->Body=
            '
            <html>
            <head></head>
            <body>
            <h3>Serkan Abalı</h3>
            </body>
            </html>
            ';
        $mail_gonder=$mail->send();
        if($mail_gonder){
            echo "mail gönderimi başarılı"."<br>";
            echo "3 sn sonra ana sayfaya yönlendirileceksiniz.";
                header("refresh:3;url=../index.php");
        }
        else{
            echo "mail gönderimi başarısız. Mail hata mesajı".$mail->ErrorInfo;
        }


    } else {
        echo "Girilen GSM numarası yanlıştır";
        header("refresh:2;url=../iletisim.php");
    }
}


?>