<?php
session_start();
session_destroy();  //geçerli oturumla ilişkili tüm verileri yok eder
session_unset();    //Yalnızca oturumdaki değişkenleri siler ve oturum hala mevcuttur.
                    //Yalnızca veriler kesilir.
header("Location:../girisyap.php");
?>