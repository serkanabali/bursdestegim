<?php
#GD kütüphanesi aktifleştirme.
#XAMPP Control Panel> Apache> config> php.ini> ;extension=gd> extension=gd 
session_start();
header("Content-type:image/png");
$sifre = substr(md5(rand(0, 8)), 0, 8);

if ($sifre) {
    $_SESSION["guvenlik_kodu"] = $sifre;
    $width = 150;
    $height = 50;
    $resim = ImageCreate($width, $height);
    $beyaz = ImageColorAllocate($resim, 255, 255, 255);
    $siyah = ImageColorAllocate($resim, 0, 0, 0);
    ImageFill($resim, 0, 0, $siyah);
    ImageString($resim, 10, 50, 16, $_SESSION["guvenlik_kodu"], $beyaz);
    ImagePng($resim);
    ImageDestroy($resim);
}
?>