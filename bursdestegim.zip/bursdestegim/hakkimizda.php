<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hakkımızda</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <div class="ust-kisim-sayfalar">
    <!--Header-->
    <?php
    include_once("include/header.php");
    ?>

    <!--Slogan-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 d-flex align-items-center header-yuk">
          <img src="resimler/iconlar/icon.png" class="img-fluid" alt="" />
            <div class="sayfa-baslik ms-4">
              <h3>HAKKIMIZDA</h3>
              <p>
                Burs Desteğim bir yardımlaşma platformudur.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!--Metin-->
  <div class="container my-4">
    <div class="row">
      <div class="col-md-12">
        <h3>Misyonumuz</h3>
        <hr />
        <div class="hedefler">

          <p>
            Yeni bir gelecek yaratan, insanların yaşamlarını zenginleştiren ve sosyal refaha katkıda bulunan ürünlerimiz
            dünyaya ilham vermek.
          </p>
        </div>
        <h3>Vizyonumuz</h3>
        <hr />
        <div class="hedefler">

          <p>
            “Sektörde, Türkiye’nin bir numaralı burs arayıcısı olmak,
          </p>
          <p>
            Hizmet kalitesiyle öğrencilerin birinci tercihi olarak sürekliliği sağlamak,
          </p>
          <p>
            Ülkemizde eğitim değerimize sahip çıkarak daha bilinçli bir toplum oluşmasına katkıda bulunmak.
          </p>
        </div>
      </div>
    </div>
  </div>

  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>


</body>

</html>