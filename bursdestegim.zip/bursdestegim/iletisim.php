<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>İletişim</title>
  
  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <div class="ust-kisim-sayfalar">

    <!--Header-->
    <?php
    include_once("include/header.php");
    ?>

    <!--Slogan-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 d-flex align-items-center header-yuk">
          <img src="resimler/iconlar/icon.png" class="img-fluid" alt="" />
          <div class="sayfa-baslik ms-4">
            <h3>İLETİŞİM</h3>
            <p>
              Hizmetlerimiz ya da teklifler hakkında bizlerle 7/24 iletişim
              kurmak için aşağıdaki formu kullanabilirsiniz.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--İletişim Formu-->
  <div class="container my-5">
    <div class="row">
      <div class="col-md-6">
        <h4>İletişim Formu</h4>
        <hr />
        <form name="mailName" action="functions/mail_gonder.php" method="post" novalidate>
          <div class="mb-3">
            <label for="adSoyad" class="form-label">Adı Soyadı</label>
            <input type="text" class="form-control" name="adSoyad" id="adSoyad" placeholder="Adınız ve Soyadınız" />
          </div>
          <div class="mb-3">
            <label for="eMail" class="form-label">E-posta Adresi</label>
            <input type="text" class="form-control" name="eMail" id="eMail" placeholder="E-posta Adresiniz" />
          </div>

          <div class="mb-3">
          Telefon Numarası:<br>
          <small>Lütfen Gsm numaranızı başında "0" olmadan ilgili alana yazınız. Örneğin: 5xxxxxxxxx</small><br>
          <input type="text" name="tel">
          </div>


          <div class="mb-3">
            <label for="konu" class="form-label">Konu</label>
            <input type="text" class="form-control" name="konu" id="konu" placeholder="Konu Giriniz..." />
          </div>
          <div class="mb-3">
            <label for="mesaj" class="form-label">Mesaj</label>
            <textarea class="form-control" name="mesaj" id="mesaj" rows="3"></textarea>
          </div>
          <div class="mb-3">
            <button name="gonderMail" class="btn btn-success btn-lg">
              <!--
              <i class="fa-solid fa-bars-staggered me-2 simgeler"></i>
              <i class="fa-solid fa-envelope me-2 simgeler"></i>
              -->
              Gönder
            </button>
          </div>
        </form>
      </div>
      <div class="col-md-6">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3011.5284777350357!2d28.696702375955823!3d40.991804771352825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14caa05e7a6e9d29%3A0x617400f3f8628fde!2zxLBTVEFOQlVMIEdFTMSwxZ7EsE0gw5xOxLBWRVJTxLBURVPEsCAtIE1FU0xFSyBZw5xLU0VLT0tVTFU!5e0!3m2!1str!2str!4v1692972473597!5m2!1str!2str"
        width="700" height="700" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-md-6">
        <h4><i class="fa-solid fa-location-dot me-2"></i>Adres</h4>
        <hr />
        <p>
          Cihangir Mah. Petrol Ofisi Cd. No: 7 Avcılar / İstanbul
        </p>
      </div>
      <div class="col-md-6">

      </div>
    </div>
  </div>

  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>
</body>

</html>