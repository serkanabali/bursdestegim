<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blog Yaz</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <!--Header-->
  <?php
  include_once("include/header.php");
  ?>

  <!--Blog Formu-->
  <div class="container">
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <div class="col-12">
          <font align="center" color="red">
            <h3>Blog Yazın</h3>
          </font>
        </div>

        <form name="form" action="" method="post" class="row g-3 needs-validation" novalidate>

          <div class="col-md-12">
            <label for="validationCustom01" class="form-label">E-posta Adresiniz</label>
            <input name="ePosta" type="text" class="form-control" id="validationCustom02" required>
          </div>

          <div class="col-md-12">
            <label for="validationCustom02" class="form-label">Kendinizden Bahsedin</label>
            <textarea class="form-control" name="yazi" id="yaziID" rows="3"></textarea>
          </div>

          <div class="col-md-12" style="padding:20px">
            <button name="blogKaydet" class="btn btn-primary" type="submit">Kaydet</button>
          </div>

        </form>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>


</body>

</html>

<?php
//Güncelleme

$db = new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8", "root", "");

if(isset($_POST["blogKaydet"]))
{
    $keMail=$_POST["ePosta"];
    $kblog=$_POST["yazi"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $guncelle=$db->exec("UPDATE ogrenci SET blog='$kblog' WHERE eMail='$keMail'");
    if($guncelle)
    {
        echo "Blog Yayınlama Başarılı";
        header("refresh:1;url=blog.php");
    }
    else
    {
        echo "Blog Yayınlama Başarısız";
        header("refresh:1;url=blogyaz.php");
    }
}

#Footer
include_once('include/footer.php');
?>