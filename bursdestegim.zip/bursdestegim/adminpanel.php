<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <?php
    include_once('include/head_link.php');
    ?>

</head>

<body>
    <!--Header-->
    <?php
    include_once("include/header.php");
    ?>
    
    <!--Admin Panel-->
    <div class="container">
        <div class="row">
            <font align="center" color="red">
                <h1>Admin Panel</h1>
            </font>


            <div class="col-md-6">
                <div class="col-12">
                    <font align="center" color="red">
                        <h3>Blog Panel</h3>
                    </font>
                </div>

                <form name="form" action="" method="post" class="row g-3 needs-validation" novalidate>

                    <div class="col-md-12">
                        <label for="validationCustom01" class="form-label">Ad Soyad</label>
                        <input name="adSoyadAdmin" type="text" class="form-control" id="validationCustom01" required>
                    </div>

                    <div class="col-md-12">
                        <label for="validationCustom02" class="form-label">E-posta</label>
                        <input name="mailAdmin" type="text" class="form-control" id="validationCustom02" required>
                    </div>

                    <div class="col-md-12">
                        <label for="validationCustom03" class="form-label">Şifre</label>
                        <input name="sifreAdmin" type="text" class="form-control" id="validationCustom03" required>
                    </div>

                    <div class="col-md-12">
                        <label for="validationCustom03" class="form-label">Blog</label>
                        <textarea class="form-control" name="blogAdmin" id="yaziID" rows="3"></textarea>
                    </div>

                    <div class="col-md-12" style="padding:20px">
                        <button name="ekleBlog" class="btn btn-primary" type="submit">Ekle</button>
                        <button name="silBlog" class="btn btn-primary" type="submit">Sil</button>
                        <button name="guncelleBlog" class="btn btn-primary" type="submit">Güncelle</button>
                        <button name="listeleBlog" class="btn btn-primary" type="submit">Listele</button>
                    </div>

                </form>
            </div>
            <div class="col-md-6">
                <div class="col-12">
                    <font align="center" color="red">
                        <h3>Burs Panel</h3>
                    </font>
                </div>

                <form name="form" action="" method="post" class="row g-3 needs-validation" novalidate>

                    <div class="col-md-12">
                        <label for="validationCustom01" class="form-label">Vakıf İsmi</label>
                        <input name="vakifAdmin" type="text" class="form-control" id="validationCustom01" required>
                    </div>

                    <div class="col-md-12">
                        <label for="validationCustom02" class="form-label">Açıklama</label>
                        <input name="aciklamaAdmin" type="text" class="form-control" id="validationCustom02" required>
                    </div>

                    <div class="col-md-12">
                        <label for="validationCustom03" class="form-label">URL Adresi</label>
                        <input name="urlAdmin" type="text" class="form-control" id="validationCustom03" required>
                    </div>

                    <div class="col-md-12" style="padding:20px">
                        <button name="ekleVakif" class="btn btn-primary" type="submit">Ekle</button>
                        <button name="silVakif" class="btn btn-primary" type="submit">Sil</button>
                        <button name="guncelleVakif" class="btn btn-primary" type="submit">Güncelle</button>
                        <button name="listeleVakif" class="btn btn-primary" type="submit">Listele</button>
                    </div>

                </form>
            </div>

            <div class="col-md-12" align="center">
                <a href="functions/cikis.php">
                    <button name="listele" class="btn btn-danger" type="submit">Çıkış Yap</button>
                </a>


            </div>
        </div>


    </div>

    <!--Alt Boşluk-->
    <div class="container my-4">
        <div class="row"></div>
    </div>

</body>

</html>

<?php
$db=new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8","root","");

//Ekleme ogr
if(isset($_POST["ekleBlog"]))
{
    $kadSoyad=$_POST["adSoyadAdmin"];
    $kmail=$_POST["mailAdmin"];
    $ksifre=$_POST["sifreAdmin"];
    $kblog=$_POST["blogAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $ekle=$db->exec("INSERT INTO ogrenci(adSoyad, eMail, sifre, blog) VALUES ('$kadSoyad', '$kmail', '$ksifre', '$kblog')");
    if($ekle)
    {
        echo "Ekleme Başarılı";
    }
    else
    {
        echo "Ekleme Başarısız";
    }
}
    
//Silme ogr
if(isset($_POST["silBlog"]))
{
    $kadSoyad=$_POST["adSoyadAdmin"];
    $kmail=$_POST["mailAdmin"];
    $ksifre=$_POST["sifreAdmin"];
    $kblog=$_POST["blogAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $sil=$db->exec("DELETE FROM ogrenci WHERE eMail='$kmail'");
    if($sil)
    {
        echo "Silme Başarılı";
    }
    else
    {
        echo "Silme Başarısız";
    }
}
    
//Güncelleme ogr
if(isset($_POST["guncelleBlog"]))
{
    $kadSoyad=$_POST["adSoyadAdmin"];
    $kmail=$_POST["mailAdmin"];
    $ksifre=$_POST["sifreAdmin"];
    $kblog=$_POST["blogAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $guncelle=$db->exec("UPDATE ogrenci SET adSoyad='$kadSoyad', sifre='$ksifre', blog='$kblog' WHERE eMail='$kmail'");
    if($guncelle)
    {
        echo "Güncelleme Başarılı";
    }
    else
    {
        echo "Güncelleme Başarısız";
    }
}
   
//Listeleme ogr
if(isset($_POST["listeleBlog"]))
{
    $kadSoyad=$_POST["adSoyadAdmin"];
    $kmail=$_POST["mailAdmin"];
    $ksifre=$_POST["sifreAdmin"];
    $kblog=$_POST["blogAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $listele=$db->query("SELECT * FROM ogrenci");
    while($gelenveri=$listele->fetch())
    {
        echo "<u>Ad Soyad: </u>".$gelenveri['adSoyad']."<br>"."<u>E-posta Adresi: </u>".$gelenveri['eMail']."<br>"."<u>Şifre: </u>".$gelenveri['sifre']."<br>"."<u>Blog: </u>".$gelenveri['blog']."<br>"."<hr>"."<br>";
    }
} 

//********************************************************** */

//Ekleme burs
if(isset($_POST["ekleVakif"]))
{
    $kvakif=$_POST["vakifAdmin"];
    $kaciklama=$_POST["aciklamaAdmin"];
    $kurl=$_POST["urlAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $ekle=$db->exec("INSERT INTO burs(kurum, aciklama, link) VALUES ('$kvakif', '$kaciklama', '$kurl')");
    if($ekle)
    {
        echo "Ekleme Başarılı";
    }
    else
    {
        echo "Ekleme Başarısız";
    }
}
    
//Silme burs
if(isset($_POST["silVakif"]))
{
    $kvakif=$_POST["vakifAdmin"];
    $kaciklama=$_POST["aciklamaAdmin"];
    $kurl=$_POST["urlAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $sil=$db->exec("DELETE FROM burs WHERE kurum='$kvakif'");
    if($sil)
    {
        echo "Silme Başarılı";
    }
    else
    {
        echo "Silme Başarısız";
    }
}
    
//Güncelleme burs
if(isset($_POST["guncelleVakif"]))
{
    $kvakif=$_POST["vakifAdmin"];
    $kaciklama=$_POST["aciklamaAdmin"];
    $kurl=$_POST["urlAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $guncelle=$db->exec("UPDATE burs SET aciklama='$kaciklama', link='$kurl' WHERE kurum='$kvakif'");
    if($guncelle)
    {
        echo "Güncelleme Başarılı";
    }
    else
    {
        echo "Güncelleme Başarısız";
    }
}
    
//Listeleme burs
if(isset($_POST["listeleVakif"]))
{
    $kvakif=$_POST["vakifAdmin"];
    $kaciklama=$_POST["aciklamaAdmin"];
    $kurl=$_POST["urlAdmin"];
    if($db)
    {
        echo "Veri tabanı bağlantısı başarılı"."<br>";
    }
    $listele=$db->query("SELECT * FROM burs");
    while($gelenveri=$listele->fetch())
    {
        echo "<u>Vakıf Adı: </u>".$gelenveri['kurum']."<br>"."<u>Açıklama: </u>".$gelenveri['aciklama']."<br>"."<u>URL Adresi: </u>".$gelenveri['link']."<br>"."<hr>"."<br>";
    }
} 
    
?>

<!--Footer-->
<?php
include_once('include/footer.php');
?>