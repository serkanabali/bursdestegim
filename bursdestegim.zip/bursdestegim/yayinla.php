<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Yayınla</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
    <!--Header-->
    <?php
    include_once("include/header.php");
    ?>

  <!--Burs Yayınla-->
  <div class="container">
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <div class="col-12">
          <font align="center" color="red">
            <h3>Burs Yayınlayın</h3>
          </font>
        </div>

        <form name="form" action="" method="post" class="row g-3 needs-validation" novalidate>

          <div class="col-md-12">
            <label for="validationCustom01" class="form-label">Vakıf İsmi</label>
            <input name="vakifIsim" type="text" class="form-control" id="validationCustom01" required>
          </div>

          <div class="col-md-12">
            <label for="validationCustom02" class="form-label">Açıklama</label>
            <input name="aciklama" type="text" class="form-control" id="validationCustom02" required>
          </div>

          <div class="col-md-12">
            <label for="validationCustom03" class="form-label">URL Adresi</label>
            <input name="url" type="text" class="form-control" id="validationCustom03" required>
          </div>

          <div class="col-md-12" style="padding:20px">
            <button name="yayinla" class="btn btn-primary" type="submit">Yayınla</button>
          </div>

        </form>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>

</body>

</html>

<?php
$db = new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8", "root", "");
if(isset($_POST["yayinla"])){
    $kvakif=$_POST["vakifIsim"];
    $kaciklama=$_POST["aciklama"];
    $kurl=$_POST["url"];
    
    $ekle=$db->exec(
        "INSERT INTO burs (kurum, aciklama, link)
        VALUES ('$kvakif', '$kaciklama', '$kurl')"
    );
    
    if($ekle)
    {
        echo "Yayınlama Başarılı";
        header("refresh:1;url=burslar.php");
    }
    else
    {
        echo "Yayınlama Başarısız";
        header("refresh:1;url=yayinla.php");
    }
}

#Footer
include_once('include/footer.php');
?>
