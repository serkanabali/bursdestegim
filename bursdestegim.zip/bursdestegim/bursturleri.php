<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Burs Türleri</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <div class="ust-kisim-sayfalar">
    <!--Header-->
    <?php
    include_once("include/header.php");
    ?>

    <!--Slogan-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 d-flex align-items-center header-yuk">
          <img src="resimler/iconlar/student.png" class="img-fluid" alt="" />
          <div class="sayfa-baslik ms-4">
            <h3>Burs Türleri</h3>
            <p>
              Profesyonel çalışma ekibimizle Lisans, yüksek lisans,
              ve doktora öğrencilerine hizmetler vermekteyiz.
            </p>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!--Hizmetler-->
  <div class="container-fluid hizmetlerimiz p-5">
    <div class="row text-center">
      <h4 class="display-4 text-center">Burs Türleri</h4>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/license.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Lisans Düzeyi</p>
      </div>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/degree.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Yüksek Lisans Düzeyi</p>
      </div>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/doctorate.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Doktora Düzeyi</p>
      </div>
    </div>
  </div>

  <!--Alt Boşluk-->
  <div class="container my-4">
    <div class="row"></div>
  </div>

  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>

</body>

</html>