<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Blog</title>
  
  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <!--Header-->
  <?php
  include_once("include/header.php");
  ?>

  <!--Metin-->
  <div class="container my-5">
    <div class="row">
      <div class="col-md-4">
        <img src="resimler/blog/asli.webp" class="img-fluid w-100" alt="" />
        <h5 class="my-3">Aslı Kaya</h5>
        <p class="text-black-50">
          <i class="fa-solid fa-calendar-days me-2"></i>24.08.2023
        </p>
        <p class="my-2">
          Merhaba, ben Aslı. 24 yaşındayım ve İstanbul’da yaşıyorum. Marmara Üniversitesi 'İş Sağlığı ve Güvenliği'
          yüksek lisans öğrencisiyim. Yaklaşık 2 yıldır İş Sağlığı alanında çalışıyorum.

        </p>

      </div>
      <div class="col-md-4">
        <img src="resimler/blog/ahmet.jpg" class="img-fluid w-100" alt="" />
        <h5 class="my-3">Ahmet Yılmaz</h5>
        <p class="text-black-50">
          <i class="fa-solid fa-calendar-days me-2"></i>24.08.2023
        </p>
        <p class="my-2">
          Merhaba, ben Ahmet. 25 yaşındayım ve İstanbul’da yaşıyorum. İstanbul Üniversitesi İngiliz Dili ve Edebiyatı
          yüksek lisans öğrencisiyim. Yaklaşık 2 yıldır dijital pazarlama alanında çalışıyorum.

          Benim en büyük tutkum, yazı yazmak ve yaratıcı içerikler üretmek. Yaratıcı yönümü keşfettiğimden beri, blog
          yazıları, şiirler ve öyküler yazıyorum. Yazı yazmayı bir hobi olarak görürken, zamanla bunu bir kariyer
          fırsatına dönüştürdüm. Şimdi, birçok farklı marka için yazarlık yapıyorum ve aynı zamanda kendi blogumda da
          yazılar paylaşıyorum.
        </p>

      </div>
      <div class="col-md-4">
        <img src="resimler/blog/ayse.jpg" class="img-fluid w-100" alt="" />
        <h5 class="my-3">Ayşe Demir</h5>
        <p class="text-black-50">
          <i class="fa-solid fa-calendar-days me-2"></i>24.08.2023
        </p>
        <p class="my-2">
          Merhaba, ben Ayşe. 18 yaşındayım ve İstanbul’da yaşıyorum. Bursa Uludağ Üniversitesi Veterinerlik lisans öğrencisiyim.

          Benim en büyük tutkum, hayvanlara yardım etmek.
        </p>

      </div>
                    <!--PHP KOD BLOKLARI-->
                    <?php
                    echo "<hr />";

                    $db=new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8","root","");
                    
                    //Listeleme
            
                $listele=$db->query("SELECT * FROM ogrenci");
                while($gelenveri=$listele->fetch())
                {
                    echo "<u>Ad Soyad: </u>".$gelenveri['adSoyad']."<br>"."<u>E-posta Adresi: </u>".$gelenveri['eMail']."<br>"."<u>Hakkımda: </u>".$gelenveri['blog']."<br>"."<hr>"."<br>";
                }
            
                    ?>
    </div>
  </div>
  
  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>
</body>

</html>