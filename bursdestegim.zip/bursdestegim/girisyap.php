<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/girisyap.css">
  <title>Giriş Yap</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <!--Header-->
  <?php
  include_once("include/header.php");
  ?>

  <!--Giriş-Üye Ol Kısmı-->
  <div class="container">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10">

        <!--Giriş Formu-->
        <div class="wrapper">
          <form class="form-signin" name="form" action="functions/veritabani.php" method="post">
            <h2 class="form-signin-heading">Giriş Yap</h2>
            <input type="text" class="form-control" name="eMail" placeholder="E-posta Adresi" required=""
              autofocus="" />
            <input type="password" class="form-control" name="sifre" placeholder="Şifre" required="" />
            <br>
            <table>
              <tr>
                <td>Güvenlik Kodu</td>
                <td><img src="functions/guvenlik_resmi.php"></td>
              </tr>
              <tr>
                <td>Güvenlik Kodunu Giriniz:</td>
                <td><input type="text" name="guvenlik_kodu"></td>
              </tr>
            </table>

            <div>
              <a href="blogyaz.php">
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="giris">Giriş Yap</button>
              </a>
          </form>
        </div>

        <div align="center">
          <a href="kayit.php">
            <button class="btn btn-lg btn-primary btn-block" type="submit">Üye Ol</button>
          </a>
        </div>
      </div>
    </div>
    <div class="col-md-1"></div>
  </div>
  </div>

  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>

</body>

</html>