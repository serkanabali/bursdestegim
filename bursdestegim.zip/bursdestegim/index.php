<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Burs Desteğim</title>

  <?php
  include_once('include/head_link.php');
  ?>

</head>

<body>

  <!--Üst Kısım-->
  <div class="ust-kisim">

    <!--Header-->
    <?php
    include_once('include/header.php');
    ?>

    <!--Slogan-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 d-flex flex-column align-items-center justify-content-center">
          <img src="resimler/iconlar/icon.png" class="img-fluid bosluk mb-4" alt="" />
          <h1 class="display-2 text-center text-white fw-bold shadow">
            Burs Desteğim bir yardımlaşma platformudur
          </h1>
          <h2 class="display-3 text-center text-white fw-bold shadow">
            Tamamen sosyal sorumluluk kapsamında geliştirilmiş bir sitedir.
          </h2>
        </div>
      </div>
    </div>

  </div>

  <!--Yayınla Kısmı-->
  <div class="container-fluid mt-3 mb-3">
    <div class="row p-4">
      <div class="col-md-12 teklif d-flex justify-content-around align-items-center">
        <p class="imza">
          <span class="tirnak">Burs</span>vermek
          <span class="tirnak">istiyorum.</span>
        </p>
        <a href="yayinla.php">
          <button class="btn btn-warning">Yayınla</button>
        </a>
      </div>
    </div>
  </div>

  <!--Burs Türleri-->
  <div class="container-fluid hizmetlerimiz p-5">
    <div class="row text-center">
      <h4 class="display-4 text-center">Burs Türleri</h4>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/license.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Lisans Düzeyi</p>
      </div>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/degree.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Yüksek Lisans Düzeyi</p>
      </div>
      <div class="col-md-4">
        <img src="resimler/burs_turleri/doctorate.png" class="img-fluid" alt="" />
        <p class="text-black-50 fw-bolder mt-2">Doktora Düzeyi</p>
      </div>
    </div>
  </div>

  <!--Ekip-->
  <div class="container kimiz py-3">
    <div class="row">
      <h2 class="display-3 text-center">Ekip</h2>
      <div class="col-md-6">
        <h3>Amaç</h3>
        <p>
          bursdestegim.org, eğitime verilecek desteğin artırılması ve eğitimde fırsat eşitliği sağlanması
          adına, bütün diğer vakıf, dernek ve burs veren ticari markalar ile kişilere açık bir şekilde
          kurulmuştur. Kar gütme amacı taşımaz.
        </p>
      </div>
      <div class="col-md-6">
        <img src="resimler/isim_logo/logosiyah.png" class="img-fluid" alt="">
      </div>

      <!--Çalışanlar-->
      <div class="col-md-12 d-md-flex justify-content-md-between ">
        <div class="calisan d-md-flex flex-md-column d-flex flex-row align-items-center text-center mb-4">
          <img src="resimler/calisan/person.png" class="img-fluid bg-danger rounded-circle" alt="">
          <h4 class="text-black ms-2">Serkan</h4>
          <h5 class="text-black-50 ms-4">Developer</h5>
        </div>
      </div>
    </div>
  </div>

  <!--Slogan-->
  <div class="container-fluid slogan text-center p-5">
    <p class="soz text-center mt-5">
      <!--
        <i class="fa-solid fa-quote-left tirnak1"></i>
      -->
      <i class="fa-solid fa-handshake-angle tirnak1"></i>
      Tamamen sosyal sorumluluk kapsamında geliştirilmiş bir sitedir.
    </p>
    <p class="mt-3"></p>
  </div>

  <!--Burslar-->
  <div class="container mt-4 mb-3">
    <div class="row ">
      <h3 class="text-center display-4 mb-3">Burslar</h3>
      <div class="col-md-12 mt-3 d-md-flex justify-content-md-between">
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://cometogelisim.com/burs-sartlari/" target="_blank">
            <img src="resimler/burslar/igu.png" class="img-fluid" alt="">
          </a>
          <p class="mt-3">İstanbul Gelişim Üniversitesi</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.cemvakfi.org/" target="_blank">
            <img src="resimler/burslar/cem.png" class="img-fluid" alt="">
          </a>
          <p class="mt-3">Cem Vakfı</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.temaconstruction.com.tr/" target="_blank">
            <img src="resimler/burslar/tema.jpeg" class="img-fluid" alt="">
          </a>
          <p class="mt-3">Tema Construction Emlak Danışmanlık</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.nesinvakfi.org/" target="_blank">
            <img src="resimler/burslar/nesin.png" class="img-fluid" alt="">
          </a>
          <p class="mt-3">Nesin Vakfı</p>
        </div>
      </div>
    </div>
  </div>

  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>

</body>

</html>