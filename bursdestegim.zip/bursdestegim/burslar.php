<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Burslar</title>

  <?php
  include_once('include/head_link.php');
  ?>
</head>

<body>
  <div class="ust-kisim-sayfalar">
    <!--Footer-->
    <?php
    include_once("include/header.php");
    ?>

    <!--Slogan-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 d-flex align-items-center header-yuk">
          <img src="resimler/iconlar/businessman.png" class="img-fluid" alt="" />
          <div class="sayfa-baslik ms-4">
            <h3>Burslar</h3>
            <p>
              Tüzel veya kurumsal tüm vakıfların öğrencilere sağladığı bursları tek bir noktada topluyoruz.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--Gövde Kısmı-->
  <div class="container mt-4 mb-3">
    <div class="row">
      <h3 class="text-center display-4 mb-3">Burslar</h3>

      <!--Yayınla Kısmı-->
      <div class="container-fluid mt-3 mb-3">
        <div class="row p-4">
          <div class="col-md-12 teklif d-flex justify-content-around align-items-center">
            <p class="imza">
              <span class="tirnak">Burs</span>vermek
              <span class="tirnak">istiyorum.</span>
            </p>
            <a href="yayinla.php">
              <button class="btn btn-warning">Yayınla</button>
            </a>
          </div>
        </div>
      </div>

      <!--Vakıf Resimleri-->
      <div class="col-md-12 mt-3 d-md-flex justify-content-md-between">
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://cometogelisim.com/burs-sartlari/" target="_blank">
            <img src="resimler/burslar/igu.png" class="img-fluid" alt="" />
          </a>
          <p class="mt-3">İstanbul Gelişim Üniversitesi</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.cemvakfi.org/" target="_blank">
            <img src="resimler/burslar/cem.png" class="img-fluid" alt="" />
          </a>
          <p class="mt-3">Cem Vakfı</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.temaconstruction.com.tr/" target="_blank">
            <img src="resimler/burslar/tema.jpeg" class="img-fluid" alt="" />
          </a>
          <p class="mt-3">Tema Construction Emlak Danışmanlık</p>
        </div>
        <div class="calisma text-center d-flex flex-column d-md-block">
          <a href="https://www.nesinvakfi.org/" target="_blank">
            <img src="resimler/burslar/nesin.png" class="img-fluid" alt="" />
          </a>
          <p class="mt-3">Nesin Vakfı</p>
        </div>
      </div>

      <!--PHP KOD BLOKLARI-->
      <?php
        echo "<hr />";
        $db=new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8","root","");
              
        //Listeleme
        $listele=$db->query("SELECT * FROM burs");
        while($gelenveri=$listele->fetch())
        {
          echo "<u>Vakıf İsmi: </u>".$gelenveri['kurum']."<br>"."<u>Açıklama: </u>".$gelenveri['aciklama']."<br>"."<u>URL Adresi: </u>".$gelenveri['link']."<br>"."<hr />"."<br>";
        }
      ?>

    </div>
  </div>


  <!--Footer-->
  <?php
  include_once('include/footer.php');
  ?>
</body>

</html>