<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kayıt Ekranı</title>

    <?php
    include_once('include/head_link.php');
    ?>
</head>

<body>
    <!--
    include_once("include/header.php");
    -->
    
    <!--Kayıt Formu-->
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">

                <div class="col-12">
                    <font align="center" color="red">
                        <h2>Üye Ol</h2>
                    </font>

                </div>

                <form name="form" action="" method="post" class="row g-3">
                    <div class="col-12">
                        <label for="inputEmail4" class="form-label">Adınız Soyadınız</label>
                        <input type="text" class="form-control" name="adSoyad" placeholder="Ad Soyad giriniz"
                            required="" autofocus="" />
                    </div>
                    <div class="col-12">
                        <label for="inputEmail4" class="form-label">E-posta</label>
                        <input type="text" class="form-control" name="eMail" placeholder="E-posta giriniz" required=""
                            autofocus="" />
                    </div>
                    <div class="col-12">
                        <label for="inputPassword4" class="form-label">Şifre</label>
                        <input type="password" class="form-control" name="sifre" placeholder="Şifre giriniz" required=""
                            autofocus="" />
                    </div>
                    <div class="col-12">
                        <button name="gonder" type="submit" class="btn btn-primary">Üye Ol</button>
                    </div>

                </form>
                <div>
                    <a href="girisyap.php">
                        <button class="btn btn-lg btn-primary btn-block" type="submit">Zaten Hesabım Var</button>
                    </a>
                </div>
            </div>

            <div class="col-md-4"></div>
        </div>
    </div>

    <!--Alt Boşluk-->
    <div class="container my-4">
        <div class="row"></div>
    </div>


</body>

</html>


<?php
$db = new PDO("mysql:host=localhost; dbname=bursdestegim; charset=utf8", "root", "");
if(isset($_POST["gonder"])){
    $kadSoyad=$_POST["adSoyad"];
    $keMail=$_POST["eMail"];
    $ksifre=$_POST["sifre"];
    
    $gsifre=$ksifre;
    
    //$gsifre=sha1(md5($ksifre));
    //$gsifre = password_hash($ksifre, PASSWORD_DEFAULT);
    
    $ekle=$db->exec(
        "INSERT INTO ogrenci (adSoyad, eMail, sifre)
        VALUES ('$kadSoyad', '$keMail', '$gsifre')"
    );
    
    if($ekle)
    {
        echo "Kayıt Başarılı";
        header("refresh:1;url=girisyap.php");
    }
    else
    {
        echo "Kayıt Başarısız";
        header("refresh:1;url=kayit.php");
    }
}

include_once('include/footer.php');
?>