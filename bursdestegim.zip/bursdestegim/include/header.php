    <nav class="navbar navbar-expand-lg nav-bg">
      <div class="container p-0">
        <a class="navbar-brand" href="index.php">
          <img class="img-fluid logo" src="resimler/isim_logo/logo.png" alt="" />
        </a>
        <button class="navbar-toggler me-2" type="button" data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon">

          </span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0 pozisyon">
            <li class="nav-item d-flex align-items-center p-2">
              <a class="nav-link active" aria-current="page" href="hakkimizda.php">Hakkımızda</a>
              <span class="ayrac">|</span>
            </li>
            <li class="nav-item d-flex align-items-center p-2">
              <a class="nav-link" href="bursturleri.php">Burs Türleri</a>
              <span class="ayrac">|</span>
            </li>
            <li class="nav-item d-flex align-items-center p-2">
              <a class="nav-link" href="burslar.php">Burslar</a>
              <span class="ayrac">|</span>
            </li>
            <li class="nav-item d-flex align-items-center p-2">
              <a class="nav-link" href="blog.php">Blog</a>
              <span class="ayrac">|</span>
            </li>
            <li class="nav-item d-flex align-items-center p-2">
              <a class="nav-link" href="iletisim.php">İletişim</a>
            </li>
            <a href="girisyap.php" class="nav-item d-flex align-items-center p-2">
              <button type="button" class="btn btn-secondary">Giriş Yap</button>
            </a>
          </ul>

        </div>
      </div>
    </nav>