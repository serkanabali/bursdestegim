  <div class="container-fluid footer">
    <div class="row">
      <div class="col-md-12 footer-sutun d-flex flex-column justify-content-center align-items-center">
        <div class="icons">
          <i class="fa-brands fa-instagram-square fa-3x me-2"></i>
          <i class="fa-brands fa-facebook-square fa-3x me-2"></i>
          <i class="fa-brands fa-twitter-square fa-3x me-2"></i>
          <i class="fa-brands fa-youtube fa-3x"></i>
        </div>
        <p class="mt-3">Copyright © 2023 bursdestegim.org</p>
        <p>
          Tüm Hakları Saklıdır.
        </p>
      </div>
    </div>
  </div>