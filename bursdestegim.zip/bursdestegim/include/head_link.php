<link rel="stylesheet" href="css/bootstrap.css" />
<link rel="stylesheet" href="css/stil.css" />
<link rel="icon" href="resimler/iconlar/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
<script src="js/bootstrap.js"></script>